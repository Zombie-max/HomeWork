public class iFrameAndTabHandling {

    static void iFrame() {
        // No real code here...
    }
}
