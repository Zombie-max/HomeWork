public class ScrollDnWithJS {
    static void scrollDn() {
        // No real code here...
    }
}
