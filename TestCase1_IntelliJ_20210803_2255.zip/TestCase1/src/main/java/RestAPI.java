public class RestAPI {
    static void apiCase() {
        // No real code here...
    }
}
