public class VerifyErrorMessages {

    static void withEmptyFields() {
        // No real code here...
    }
}
